class Overtaking:
    Angle = 0
    Distance = 0
    Speed = 0
    def __init__(self):
        self.__lane_keeping_maneouvre = None




