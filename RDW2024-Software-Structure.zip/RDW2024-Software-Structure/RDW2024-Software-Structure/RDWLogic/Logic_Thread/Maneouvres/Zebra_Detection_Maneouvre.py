class Zebra_Detection_Maneouvre:
    def __init__(self):
        self.__lane_keeping_maneouvre = None

