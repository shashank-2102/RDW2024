# Given a frame, and a area on the frame, the method calulates the distance of the object from the camera
def Calculate_Distance();